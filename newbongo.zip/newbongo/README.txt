This is the content management system developed by Rednet Corporation.
email:info@rednet.co.tz
phone:+255765834754
website:www.rednet.co.tz

With this sytem you can easily and seamlessly setup your website/blog and manage it on the admin dashboard.
--------------------------------Setup insstructions-----------------------------------------------
1.After downloading the zipped file,paste it in the document root folder of your localhost.
2.Extract the file (bongoblog.zip)
3.Inside the extracted folder find a folder named databasefile,take the file named blog_admin_db.sql and go create a database called blog_admin_db and import the sql file there.
4.after importing all the tables successfully,you are now set to start using your web system

to login in to the admin dashboard simply click on the link named sign in on the website and login using
user:admin
pass:admin

On your admin dashboard you can easily customize the entire webiste by changing its name,tagline,icon,editing the social links,adding categories,manage blog posts,selecting favourite posts as editor's choice and much more.It is very easy using the admin dashboard,everything works like magic.
New users can sign up to the system as authors to contribute content to the website or blog if you wish to.
for more advanced settings you can contact me on whatsapp via the mobile phone number provided above.