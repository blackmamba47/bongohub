<?php
//database connection
($GLOBALS["___mysqli_ston"] = mysqli_connect("localhost","bongohub_bongo","Bongocomputer255@tz.tz","bongohub_blog_admin_db"));  //host,user,password,database
?>
