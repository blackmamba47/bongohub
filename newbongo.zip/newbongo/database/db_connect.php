<?php
$con=mysqli_connect("localhost","bongohub_bongo","Bongocomputer255@tz.tz","bongohub_blog_admin_db");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
 ?>