<?php
	$database_username = 'bongohub_bongo';//user name
	$database_password = 'Bongocomputer255@tz.tz';//password
	$pdo_conn = new PDO( 'mysql:host=localhost;dbname=bongohub_blog_admin_db', $database_username, $database_password );
?>
