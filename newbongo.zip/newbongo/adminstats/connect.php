<?php
$dsn='mysql:host=localhost;dbname=blog_admin_db';//dbname and host
$username='bongohub_bongo';//username
$password='Bongocomputer255@tz.tz';//password
?>